const express = require("express")
 
const Follow = require("../models/Follow.model")

const router=express.Router()

router.get("follower",async(req,res)=>{
    try {
        const follower=await Follow.find({userId:req.params.id}).populate({"path":"follower",select:["username","email"]}).lean().exec()
        return res.status(201).send(follower)
    } catch (error) {
        return res.status(401).send(error.message)
    }
})

module.exports= router