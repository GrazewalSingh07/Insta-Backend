const express=require("express");
const router= express.Router();
const User=require("../models/user.model")
 const cloudinary= require("../utils/cloudinary")
 const upload=require("../utils/multer")
 
const {body, validationResult}=require("express-validator")
 
router.post("/",upload.single('image'),async(req,res)=>{
    try {
        
        
        const result= await cloudinary.uploader.upload(req.file.path)
        
         
         let curr=  await new User({
                username:req.body.username,
                email:req.body.email,
                password:req.body.password,
                fullname:req.body.fullname,
                phone:req.body.phone,
                avatar:result.secure_url,
                cloudinary_Id:result.public_id
             }) 
             await curr.save()
        return res.status(200).send(curr)
       
    } catch (error) {
        if(error.code===11000){
           return res.status(500).send("Register successful please login")
        }
        return res.status(400).send(error)
        
    }
})
router.get("/" ,async(req,res)=>{
    try {
        const user= await User.find().lean().exec()
      return  res.status(200).send(user)
    } catch (error) {
        res.status(500).send({error:error.message})
    }
})


router.delete("/:id",async(req,res)=>{
    try {
        let user=await User.findById(req.param.id)
        await cloudinary.uploader.destroy(user.cloudinary_id)
        await user.remove()
      return  res.status(201).send({"message":"deleted sucessfully","user":user})
    } catch (error) {
        return res.status(401).send(error.message)
    }
})
router.patch("/:id",upload.single('image'),async(req,res)=>{
    try {
        let user=await User.findById(req.param.id)
        await cloudinary.uploader.destroy(user.cloudinary_id)
        const result= await cloudinary.uploader.upload(req.file.path)
         
        const data={
            username:req.body.username||user.username,
            email:req.body.email||user.email,
            password:req.body.password||user.password,
            fullname:req.body.fullname||userfullname,
            phone:req.body.phone||user.phone,
            avatar:result.secure_url||user.avatar,
            cloudinary_Id:result.public_id||user.cloudinary_id
        }
        user= await User.findByIdAndUpdate(req.param.id,data,{new:true})

        



      return  res.status(201).send({"message":"updated sucessfully","user":user})
    } catch (error) {
        return res.status(401).send(error.message)
    }
})

module.exports= router